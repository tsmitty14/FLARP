<html>
	<form action="tyreg.php" method="post">
				<p>Player name: <input type = "text" name="name"></p>
				<p>Age: <input type = "number" name="age"></p>
				<p>Height: <input type = "number" name="height" ></p>
				<p>Weight: <input type = "number" name="weight" ></p>
				<p>Preferred Team: <input type = "text" name="team" ></p>
				<input type="submit">
	</form>
</html>